﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace StakHappy.Api.Controllers
{
    public abstract class BaseController<M, L> : Controller
        where M : class, Core.Data.Model.IEntity, new()
        where L : Core.Logic.LogicBase<M>, new()
    {
        public readonly Guid UserId;
        public readonly L Logic;
        public BaseController()
        {
            //Guid.TryParse(this.Request.Headers["UserId"], out UserId);
            Logic = new L();
        }

        // GET api/values
        [HttpGet]
        public virtual IQueryable<M> Get()
        {
            //throw new NotImplementedException();
            throw new UnauthorizedAccessException();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public virtual M Get(Guid id)
        {
            return Logic.Get(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody]M entity)
        {
            Logic.Save(entity);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]M entity)
        {
            Logic.Save(entity);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(Guid id)
        {
            Logic.Delete(id);
        }
    }
}
